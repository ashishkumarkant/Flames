/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.relation;

/**
 *
 * @author ashu
 */
public class Relation {
    public String theRelation(String s){
        switch(s){
            case "F":
                s="Friend";
                break;
            case "L":
                s="LOVER";
                break;
            case "A":
                s="AFFAIR";
                break;
            case "M":
                s="MARRIGE";
            case "E":
                s="ENEMY";
                break;
            case "S":
                s="SISTER";
                break;
        }
        return s;
    }
}
