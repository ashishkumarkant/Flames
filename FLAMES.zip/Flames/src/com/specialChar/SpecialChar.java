/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.specialChar;

/**
 *
 * @author ashu
 */
public class SpecialChar {
    public boolean specialChar(String s){
        boolean result=false;
        int n;
        for(int i=0;i<s.length();i++){
            n=s.charAt(i);
            if((n>=97 && n<=122) ||(n>=65 && n<=90)){
                result=true;
            }
            else{
                result=false;
                break;
            }
        }
        return result;
    }
}
