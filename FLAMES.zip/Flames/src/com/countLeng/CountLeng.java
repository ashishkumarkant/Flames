/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.countLeng;

/**
 *
 * @author ashu
 */
public class CountLeng {
    public int countLeng(String s){
        int count=0;
        int rep=1;
        char ch;
        String ss="";
        if(s.length()<=1){
            count++;
        }
        else{
            while(s.length()>0){
                if(s.length()==1){
                    count++;
                    break;
                }
                ch=s.charAt(0);
                for(int i=1;i<s.length();i++){
                    if(ch==s.charAt(i)){
                        rep++;
                    }
                    else{
                        ss+=String.valueOf(s.charAt(i));
                    }
                }
                if(rep%2!=0){
                    count++;
                }
                s=ss;
                ss="";
                rep=1;
            }
        }    
        return count;
    }
}
