/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.removeSpaces;

/**
 *
 * @author ashu
 */
public class RemoveSoaces {
    public String removeSpeces(String s){
        int l=s.length();
        String ss="";
        for(int i=0;i<l;i++){
            if(s.charAt(i)==' '){
                continue;
            }
            else{
                ss+=String.valueOf(s.charAt(i));
            }
        }
        
        return ss;
    }
}
