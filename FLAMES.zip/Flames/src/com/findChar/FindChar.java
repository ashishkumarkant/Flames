/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.findChar;

/**
 *
 * @author ashu
 */
public class FindChar {
    public String findChar(int n){
        int t=0;
        String s="FLAMES";
        String ss="";
        String sss="";
        while(s.length()>1){
            if(n>s.length()){
                if(n%s.length()==0){
                    t=s.length()-1;
                }
                else{
                    t=n%s.length()-1;
                }
            }
            if(n==s.length()){
                t=s.length()-1;
            }
            if(n<s.length()){
                t=n-1;
            }
            for(int i=0;i<s.length();i++){
                if(i<t){
                   sss+=String.valueOf(s.charAt(i));
                   continue;
                }
                if(i==t){
                    continue;
                }
                else{
                    ss+=String.valueOf(s.charAt(i));
                }
            }
            s=ss+sss;
            ss="";
            sss="";
        }
        return s;
    }
}
